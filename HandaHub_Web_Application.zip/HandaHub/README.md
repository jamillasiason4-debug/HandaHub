# HandaHub — Community Disaster Preparedness System

A responsive blue-and-white student web application built with HTML, CSS, and JavaScript. It uses browser `localStorage`; there is no backend server.

## Files
- `index.html` — application pages and content
- `style.css` — responsive layout and visual design
- `script.js` — navigation, checklist, progress score, directory search, add/remove entries, and browser storage

## Run locally
1. Download and extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Navigate with the top menu. On smaller screens, use the menu button.
4. Check and uncheck go-bag items; the dashboard percentage should update.
5. Add a center/contact in the relevant directory form, then refresh. The item should remain in the same browser.
6. Try searching directory entries and removing user-added entries.
7. Reset the go-bag checklist to test its reset confirmation.

For best testing, run through a local static server or use the deployment steps below. Browser storage is scoped to the origin, so data saved on `file://` may behave differently between browsers.

## Deploy with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new repository, for example `handahub`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository's root.
4. Open **Settings → Pages**.
5. Under the build/deployment section, choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish and open the URL shown on the Pages settings screen.
7. Test the URL in a private/incognito window and on a phone. Confirm that all pages load and interactions work.

Alternative: upload the three files to a static hosting provider such as Netlify, following its current deployment instructions.

## Important limitations
- This is a front-end demo, not a live alert or emergency dispatch system.
- Directory entries supplied by the app are fictional sample placeholders. Do not rely on them during an emergency. Replace with current details verified by the LGU/barangay or relevant official office.
- User-added directory entries are labeled for verification. Browser storage is local to that browser/device and is not shared across users or devices. Clearing browser data can erase it.
- The readiness percentage reflects only how many checklist boxes are checked. It is not a professional assessment of household safety.
- General safety guidance is educational and should not override current instructions from official emergency authorities.

## Submission screenshot suggestions
Capture real screenshots from your deployed application:
1. Home page — introduction and demo-information warning.
2. Dashboard — readiness score and quick actions.
3. Go-Bag Checklist — item checkboxes and updated percentage.
4. Safety Guides — the hazard guide cards and one expanded guide.
5. Evacuation Centers — sample warning, search, and directory.
6. Emergency Contacts — sample warning and contact directory.
7. About — purpose, limitations, and technologies.
