/* HandaHub demo application.
   All directory data below is SAMPLE PLACEHOLDER DATA.
   Replace it with information verified through official local authorities before real-world use. */
"use strict";

const STORAGE_KEYS = {
  checklist: "handahub_checklist_v1",
  centers: "handahub_centers_v1",
  contacts: "handahub_contacts_v1"
};

const checklistItems = [
  { id: "water", name: "Drinking water", detail: "Store enough for household needs" },
  { id: "food", name: "Ready-to-eat food", detail: "Choose non-perishable items" },
  { id: "firstaid", name: "First-aid kit", detail: "Include basic first-aid supplies" },
  { id: "light", name: "Flashlight or headlamp", detail: "Check batteries or charge level" },
  { id: "radio", name: "Battery or hand-crank radio", detail: "For official updates if available" },
  { id: "power", name: "Power bank and cables", detail: "Keep devices charged when possible" },
  { id: "documents", name: "Important documents", detail: "Keep copies in a waterproof pouch" },
  { id: "cash", name: "Cash and payment essentials", detail: "Small bills where possible" },
  { id: "clothes", name: "Extra clothes and hygiene items", detail: "Include sturdy footwear if needed" },
  { id: "medicine", name: "Personal medicines", detail: "Follow medical instructions and expiry dates" },
  { id: "whistle", name: "Whistle and basic tools", detail: "For signaling and simple needs" },
  { id: "special", name: "Household-specific supplies", detail: "Infants, older adults, disability, or pets" }
];

// These names and details are intentionally fictional placeholders.
const sampleCenters = [
  { id: "sample-center-1", name: "Sample Community Hall", address: "Sample Barangay, replace with verified address", contact: "Sample contact — verify locally", sample: true },
  { id: "sample-center-2", name: "Sample Public School Gym", address: "Sample District, replace with verified address", contact: "Sample contact — verify locally", sample: true },
  { id: "sample-center-3", name: "Sample Covered Court", address: "Sample Purok, replace with verified address", contact: "Sample contact — verify locally", sample: true }
];
const sampleContacts = [
  { id: "sample-contact-1", name: "Local Disaster Risk Reduction Office", phone: "Replace with verified official number", notes: "Verify with your LGU", sample: true, icon: "⌂" },
  { id: "sample-contact-2", name: "Local Fire Service", phone: "Replace with verified official number", notes: "Verify with your local fire station", sample: true, icon: "♨" },
  { id: "sample-contact-3", name: "Local Police Station", phone: "Replace with verified official number", notes: "Verify with your local police station", sample: true, icon: "✦" },
  { id: "sample-contact-4", name: "Barangay Office", phone: "Replace with verified official number", notes: "Add your barangay's current contact", sample: true, icon: "☎" }
];

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    console.warn("Could not read local browser storage:", error);
    return fallback;
  }
}
function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.warn("Could not save local browser storage:", error);
    showToast("Could not save. Check your browser storage settings.");
    return false;
  }
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}
function showToast(message) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2800);
}

let checkedItems = readStorage(STORAGE_KEYS.checklist, []);
if (!Array.isArray(checkedItems)) checkedItems = [];
let centers = readStorage(STORAGE_KEYS.centers, null);
let contacts = readStorage(STORAGE_KEYS.contacts, null);
if (!Array.isArray(centers)) centers = sampleCenters;
if (!Array.isArray(contacts)) contacts = sampleContacts;

function navigateTo(pageId, updateHash = true) {
  const validPage = document.getElementById(pageId) && document.getElementById(pageId).classList.contains("page-section");
  const page = validPage ? pageId : "home";
  document.querySelectorAll(".page-section").forEach(section => {
    section.hidden = section.id !== page;
  });
  document.querySelectorAll(".nav-link").forEach(link => {
    const active = link.dataset.page === page;
    link.classList.toggle("active", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  const nav = document.getElementById("main-nav");
  const toggle = document.getElementById("menu-toggle");
  nav.classList.remove("open");
  toggle.setAttribute("aria-expanded", "false");
  if (updateHash && location.hash !== "#" + page) history.pushState({ page }, "", "#" + page);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.addEventListener("click", event => {
  const link = event.target.closest('a[href^="#"]');
  if (!link) return;
  const pageId = link.getAttribute("href").slice(1);
  const target = document.getElementById(pageId);
  if (target && target.classList.contains("page-section")) {
    event.preventDefault();
    navigateTo(pageId);
  }
});
window.addEventListener("popstate", () => navigateTo(location.hash.slice(1) || "home", false));

document.getElementById("menu-toggle").addEventListener("click", () => {
  const nav = document.getElementById("main-nav");
  const toggle = document.getElementById("menu-toggle");
  const isOpen = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(isOpen));
});

function renderChecklist() {
  const root = document.getElementById("checklist-items");
  root.innerHTML = checklistItems.map(item => `
    <label class="check-item">
      <input type="checkbox" data-item-id="${item.id}" ${checkedItems.includes(item.id) ? "checked" : ""}>
      <span><strong>${escapeHTML(item.name)}</strong><small>${escapeHTML(item.detail)}</small></span>
    </label>
  `).join("");
  root.querySelectorAll("input[type=checkbox]").forEach(input => {
    input.addEventListener("change", () => {
      const id = input.dataset.itemId;
      checkedItems = input.checked
        ? [...new Set([...checkedItems, id])]
        : checkedItems.filter(itemId => itemId !== id);
      writeStorage(STORAGE_KEYS.checklist, checkedItems);
      updateProgress();
    });
  });
  updateProgress();
}
function updateProgress() {
  const total = checklistItems.length;
  const done = checklistItems.filter(item => checkedItems.includes(item.id)).length;
  const percent = Math.round((done / total) * 100);
  document.getElementById("score-number").textContent = `${percent}%`;
  document.getElementById("score-count").textContent = `${done} of ${total} items checked`;
  document.getElementById("progress-ring").style.background = `conic-gradient(var(--blue-2) ${percent * 3.6}deg, #e6eef7 0deg)`;
  document.getElementById("progress-bar").style.width = `${percent}%`;
  document.getElementById("checklist-summary").textContent = `${done} of ${total} items ready`;
  document.getElementById("checklist-percent").textContent = `${percent}%`;
  document.getElementById("checklist-progress").style.width = `${percent}%`;
  document.getElementById("score-status").textContent = percent === 100 ? "Checklist complete" : percent >= 60 ? "Good progress" : percent >= 25 ? "Making progress" : "Getting started";
  document.getElementById("checklist-message").textContent = percent === 100
    ? "Great work! Review expiry dates and adjust supplies to your household's needs."
    : percent >= 60 ? "You're making progress. Review remaining items and keep supplies current."
    : "Start by checking the items you already have. Add supplies that fit your household's needs.";
}
document.getElementById("reset-checklist").addEventListener("click", () => {
  if (!window.confirm("Uncheck all go-bag items?")) return;
  checkedItems = [];
  writeStorage(STORAGE_KEYS.checklist, checkedItems);
  renderChecklist();
  showToast("Checklist reset.");
});

function renderCenters() {
  const query = document.getElementById("center-search").value.trim().toLowerCase();
  const filtered = centers.filter(center => `${center.name} ${center.address} ${center.contact}`.toLowerCase().includes(query));
  document.getElementById("center-count").textContent = `${filtered.length} ${filtered.length === 1 ? "entry" : "entries"}`;
  const root = document.getElementById("center-list");
  root.innerHTML = filtered.length ? filtered.map(center => `
    <article class="directory-card">
      <div class="card-icon" aria-hidden="true">⌖</div>
      <span class="sample-tag">${center.sample ? "SAMPLE — VERIFY" : "USER-ADDED — VERIFY"}</span>
      <h3>${escapeHTML(center.name)}</h3>
      <p><strong>Address / area</strong><br>${escapeHTML(center.address)}</p>
      <p><strong>Contact</strong><br>${escapeHTML(center.contact || "Not provided")}</p>
      ${center.sample ? "" : `<button class="button button-secondary button-small delete-center" data-id="${escapeHTML(center.id)}">Remove entry</button>`}
    </article>`).join("") : `<div class="empty-state">No entries match your search.</div>`;
  root.querySelectorAll(".delete-center").forEach(button => button.addEventListener("click", () => {
    centers = centers.filter(center => center.id !== button.dataset.id);
    writeStorage(STORAGE_KEYS.centers, centers);
    renderCenters();
    showToast("Entry removed.");
  }));
}
document.getElementById("center-search").addEventListener("input", renderCenters);
document.getElementById("center-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  centers.push({
    id: `center-${Date.now()}`,
    name: form.get("name").trim(),
    address: form.get("address").trim(),
    contact: form.get("contact").trim() || "Not provided",
    sample: false
  });
  if (writeStorage(STORAGE_KEYS.centers, centers)) {
    event.currentTarget.reset();
    renderCenters();
    showToast("Entry added to this browser. Verify details before use.");
  }
});

function renderContacts() {
  const query = document.getElementById("contact-search").value.trim().toLowerCase();
  const filtered = contacts.filter(contact => `${contact.name} ${contact.phone} ${contact.notes}`.toLowerCase().includes(query));
  document.getElementById("contact-count").textContent = `${filtered.length} ${filtered.length === 1 ? "entry" : "entries"}`;
  const root = document.getElementById("contact-list");
  root.innerHTML = filtered.length ? filtered.map(contact => `
    <article class="contact-card">
      <div class="card-icon" aria-hidden="true">${escapeHTML(contact.icon || "☎")}</div>
      <div>
        <span class="sample-tag">${contact.sample ? "SAMPLE — VERIFY" : "USER-ADDED — VERIFY"}</span>
        <h3>${escapeHTML(contact.name)}</h3>
        <p class="contact-detail">${escapeHTML(contact.phone)}</p>
        <p>${escapeHTML(contact.notes || "Verify this information with an official source.")}</p>
        ${contact.sample ? "" : `<button class="button button-secondary button-small delete-contact" data-id="${escapeHTML(contact.id)}">Remove entry</button>`}
      </div>
    </article>`).join("") : `<div class="empty-state">No entries match your search.</div>`;
  root.querySelectorAll(".delete-contact").forEach(button => button.addEventListener("click", () => {
    contacts = contacts.filter(contact => contact.id !== button.dataset.id);
    writeStorage(STORAGE_KEYS.contacts, contacts);
    renderContacts();
    showToast("Contact removed.");
  }));
}
document.getElementById("contact-search").addEventListener("input", renderContacts);
document.getElementById("contact-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  contacts.push({
    id: `contact-${Date.now()}`,
    name: form.get("name").trim(),
    phone: form.get("phone").trim(),
    notes: form.get("notes").trim() || "Verify this information with an official source.",
    sample: false,
    icon: "☎"
  });
  if (writeStorage(STORAGE_KEYS.contacts, contacts)) {
    event.currentTarget.reset();
    renderContacts();
    showToast("Contact added to this browser. Verify details before use.");
  }
});

document.getElementById("current-year").textContent = new Date().getFullYear();
renderChecklist();
renderCenters();
renderContacts();
navigateTo(location.hash.slice(1) || "home", false);
